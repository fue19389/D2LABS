/* 
 * File:   REGADC
 * Author:  Gerardo Fuentes
 * Comments:  Es la prueba para la
 * Revision history: 19 de julio 2021 20:46
 */

#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H


