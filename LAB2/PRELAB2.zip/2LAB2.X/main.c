/*
 * File:   main.c
 * Author: Pablo
 * Ejemplo de uso de la LCD 16x2 en modo 4 bits
 * Se utiliz� y se adaptaron las librer�as de Ligo George 
 * de la p�gina www.electrosome.com
 * Enlace: https://electrosome.com/lcd-pic-mplab-xc8/
 * Created on 31 de enero de 2020, 11:20 AM
 */

#pragma config FOSC = EXTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ 8000000
#define RS RC6
#define EN RC7
#define D4 RD4
#define D5 RB5
#define D6 RD6
#define D7 RD7

#include "LCD.h"
#include "adc.h"

void cfg_io();
void cfg_adc();
char f;

uint8_t valadc(uint8_t aa){
    aa = ADRESH;
    return aa;
}

void main(void) {
  cfg_io();                 //Llamado a configuraciones 
  cfg_adc();
  unsigned int a;
  TRISD = 0x00;
  TRISCbits.TRISC6 = 0;
  TRISCbits.TRISC7 = 0;
  Lcd_Init();
  ADCON0bits.GO = 1;
  
  while(1)
  {
    Lcd_Clear();
    Lcd_Set_Cursor(1,1);
    Lcd_Write_String("S1: S2:  S3:");
    
    
    /*Lcd_Set_Cursor(2,1);
    sprintf(f, "%3.2fV",vol1);
    Lcd_Write_String(f);*/

    //__delay_ms(2000);
   

    if(ADCON0bits.GO == 0){  //Proceso al acabar conversión
            __delay_us(100);     //Delay para no traslapar conversiones
            ADCON0bits.GO = 1;
         }
    return;
}
}

void cfg_io(){
    ANSELH = 0x00;  //Seteo de inputs como digitales
    ANSEL = 0x20;   //Seteo de inputs RE0 y RE1 como analógicos
    
    TRISB = 0x03;   //Pines RB0, RB1, como entradas
    TRISC = 0x00;   //PORTC, PORTA, PORTD como salidas
    TRISA = 0X00;
    TRISD = 0X00;
    TRISE = 0x03;   //Entradas RE0 y RE1
}

void cfg_adc() {            //Configuración ADC
    ADCON1bits.ADFM = 0;    //Justificar a la izquierda
    ADCON1bits.VCFG0 = 0;   //Voltaje de referencia Vss y Vdd
    ADCON1bits.VCFG1 = 0;   
    
    ADCON0bits.ADCS0 = 0;   //ADC clock Fosc/2 para 1Mhz
    ADCON0bits.ADCS1 = 0;   
    ADCON0bits.CHS = 5;     //Canal 5 selecionado para inicar
    __delay_us(100);        //Delay más largo para tiempo necesario de conver.
    ADCON0bits.ADON = 1;    //Encender módulo ADC
    
}